# Personal Desktop-Assistant

1. This application is developed in Python and has a interacting  and amazing GUI.   
2. It is possible to complete with the help of different API's.    
3. It can perform various works, like login in the accounts, opening and closing the applications.    
4. It can interact with the user with the voice command, and can perform actions according to the need of users.    
5. Technologies used - Python, QT Designer, PyQt5, API's, and different modules.   


# Features

1. It can search direclty from the Google, only with the voice command.   
2. It has a story telling mode, and can tell me daily news, jokes, current date and time.   
3. It can tell current location, current Battery Percentage.
4. Can capture images, Screenshots, and can show the photos according to the User's needs.
5. Can perform Calculations, and it has cooking mode also, for telling how to make recipes.

# Requirements

1. Python installed.
2. pip install pyautogui  
3. pip install pyttsx3  
4. pip install SpeechRecognition  
5. pip install PyAudio  
6. pip install psutil  
7. pip install cv2 
8. pip install wikipedia 
9. pip install pyjokes 
10. pip install bs4     
11. pillow library 
12. and many modules also.   

 
